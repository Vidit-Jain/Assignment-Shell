#include <bits/stdc++.h>
using namespace std;

#define MOD 1000000007
typedef long long ll;
//#define int ll 

typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<bool> vb;
typedef vector<vi> vvi;
typedef vector<ii> vii;
typedef vector<vii> vvii;
#define ff first
#define ss second
#define pb push_back
#define all(s) s.begin(), s.end()
#define tc int t; cin>>t; while(t--)
#define file_read(x,y) freopen(x, "r", stdin); \
						freopen(y, "w", stdout);
#define fightFight cin.tie(0) -> sync_with_stdio(0)

int main(){
	fightFight;
	cout << "hello\n";
	for (int i = 0; i < 10; i++) {
		cout << i << " ";
	}
}
